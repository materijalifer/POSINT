U mapi "Kod" se nalazi �itav VS solution.

U mapi aplikacija se nalazi minimum komponenata potrebnih za rad aplikacije, upute i screenshotovi.