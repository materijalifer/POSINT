﻿using System;
using System.Collections.Generic;
using System.Text;

using Model;

namespace Controller
{
	public class ConnectionFormController
	{
		private IConnectionForm connForm;

		public ConnectionFormController(IConnectionForm connForm)
		{
			if (connForm == null)
			{
				throw new ArgumentNullException("connForm", "Forma mora biti inicijalizirana");
			}

			this.connForm = connForm;
		}

		public void Connect(string connection, IMessageForm messageForm)
		{
			try
			{
				ConnectionKeeper.Connect(connection);
				ConnectionRepository.AddConnectionFirst(connection);

				connForm.Close();
			}
			catch(Exception ex)
			{
				messageForm.ShowErrorMessage(ex.Message, "Nije uspjelo spajanje na bazu.");
			}
		}
	}
}
