﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Controller
{
	public interface IMainForm
	{
		void Show();
	}
}
