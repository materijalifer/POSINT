﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Controller
{
	public interface IConnectionForm
	{
		void Show();

		void Close();
	}
}
