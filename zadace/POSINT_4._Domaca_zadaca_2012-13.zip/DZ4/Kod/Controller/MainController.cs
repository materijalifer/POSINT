﻿using System;
using System.Collections.Generic;
using System.Text;

using System.IO;
using Model;

namespace Controller
{
	public class MainController
	{
		public static void InitializeConnections()
		{
			ConnectionFileHandler fileHandler = new ConnectionFileHandler();
			IList<string> connections = ConnectionFileHandler.Connections;

			foreach (string connection in connections)
			{
				ConnectionRepository.AddConnection(connection);
			}

			ConnectionRepository.AddObserver(fileHandler);
		}

		public static void CleanUp()
		{
			if (ConnectionKeeper.ConnectionOpen)
			{
				ConnectionKeeper.Disconnect();
			}
		}

		public static void InitializeData()
		{
			FactTableRepository.InitializeData();
		}
	}
}
