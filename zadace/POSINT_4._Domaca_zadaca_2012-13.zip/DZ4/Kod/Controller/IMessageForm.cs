﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Controller
{
	public interface IMessageForm
	{
		void AddAction(string action);

		string DefaultAction { set; }

		string ShowToUser(string message, string label);

		void ShowErrorMessage(string message, string label);
	}
}
