﻿using System;
using System.Collections.Generic;

using System.Text;
using System.IO;

namespace Model
{
	public class ConnectionFileHandler : IObserver
	{
		private const string filename = "connections";

		public void Update()
		{
			FileStream file = File.Create(filename);
			StreamWriter stream = new StreamWriter(file);

			foreach (string connection in ConnectionRepository.Connections)
			{
				stream.WriteLine(connection);	
			}

			stream.Flush();
			stream.Close();
			file.Close();
		}

		public static IList<string> Connections
		{
			get
			{
				List<string> connections = new List<string>();

				try
				{
					FileStream file = File.OpenRead(filename);
					StreamReader stream = new StreamReader(file);

					while (!stream.EndOfStream)
					{
						string connection = stream.ReadLine();
						connections.Add(connection);
					}

					stream.Close();
					file.Close();
				}
				catch { }

				return connections.AsReadOnly();
			}
		}
	}
}
