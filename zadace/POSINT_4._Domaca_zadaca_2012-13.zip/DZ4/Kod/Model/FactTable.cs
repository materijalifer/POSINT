﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
	public class FactTable
	{
		private int number;
		public int Number
		{
			get { return this.number; }
		}

		private string name;
		public string Name
		{
			get { return this.name; }
		}

		private string dbName;
		public string DBName
		{
			get { return dbName; }
		}

		private List<Measure> measures = new List<Measure>();
		public IList<Measure> Measures
		{
			get { return measures.AsReadOnly(); }
		}

		private Dictionary<Column, Dimension> dimensions = new Dictionary<Column,Dimension>();
		public Dictionary<Column, Dimension> Dimensions
		{
			get { return dimensions; }
		}


		public FactTable(int number, string name, string dbName)
		{
			this.number = number;
			this.name = name;
			this.dbName = dbName;
		}

		public void AddMeasure(Measure measure)
		{
			this.measures.Add(measure);
		}

		public void AddDimension(Column foreignColumn, Dimension dimension)
		{
			this.dimensions.Add(foreignColumn, dimension);
		}
	}
}
