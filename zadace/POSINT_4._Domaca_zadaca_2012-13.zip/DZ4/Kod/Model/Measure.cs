﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
	public class Measure : Column
	{
		private List<string> aggregateFunc = new List<string>();
		public IList<string> AggregateFunc
		{
			get { return aggregateFunc.AsReadOnly(); }
		}

		private string selectedFunction;
		public string SelectedFunction
		{
			get { return selectedFunction; }
			set { selectedFunction = value; }
		}


		public Measure(int tableNumber, int number, string name, string dbName)
			:base(tableNumber, number, name, dbName){}

		public void AddAggregateFunc(string functionName)
		{
			this.aggregateFunc.Add(functionName);
		}
	}
}
