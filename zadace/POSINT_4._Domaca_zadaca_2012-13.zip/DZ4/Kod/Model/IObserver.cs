﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
	public interface IObserver
	{
		void Update();
	}
}
