﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
	public class Dimension
	{
		private int number;
		public int Number
		{
			get { return this.number; }
		}

		private string name;
		public string Name
		{
			get { return this.name; }
		}

		private string dbName;
		public string DBName
		{
			get { return dbName; }
		}

		private Column key;
		public Column Key
		{
			get { return key; }
		}

		private List<Column> attributes = new List<Column>();
		public IList<Column> Attributes
		{
			get { return attributes.AsReadOnly(); }
		}

		public Dimension(int number, string name, string dbName, Column key)
		{
			this.number = number;
			this.name = name;
			this.dbName = dbName;
			this.key = key;
		}

		public void AddAttribute(Column key)
		{
			this.attributes.Add(key);
		}
	}
}
