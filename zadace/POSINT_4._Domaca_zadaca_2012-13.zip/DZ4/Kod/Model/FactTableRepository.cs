﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
	public static class FactTableRepository
	{
		private static List<FactTable> factTables = new List<FactTable>();
		public static IList<FactTable> FactTables
		{
			get { return factTables.AsReadOnly(); }
		}

		public static void InitializeData()
		{
			factTables.AddRange(ConnectionKeeper.GetFactTables());
			if (factTables.Count > 0)
			{
				SelectedFactTable = factTables[0];
			}
		}

		public static FactTable SelectedFactTable { get; set; }
	}
}
