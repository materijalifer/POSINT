﻿using System.Collections.Generic;

using System.Data;
using System.Data.SqlClient;

namespace Model
{
	public static class ConnectionKeeper
	{
		private static SqlConnection sqlConnection;
		public static void Connect(string connection)
		{
			sqlConnection = new SqlConnection(connection);
			sqlConnection.Open();
		}

		public static void Disconnect()
		{
			if (sqlConnection != null)
			{
				sqlConnection.Close();
			}
		}

		public static bool ConnectionOpen
		{
			get
			{
				bool isOpen = false;
				
				if (sqlConnection != null)
				{
					isOpen = sqlConnection.State == ConnectionState.Open;
				}

				return isOpen;
			}
		}


		public static List<FactTable> GetFactTables()
		{
			List<FactTable> factTables = queryFactTables();

			return factTables;
		}

		private static List<FactTable> queryFactTables()
		{
			List<FactTable> factTables = new List<FactTable>();
			SqlCommand command = new SqlCommand();
			command.Connection = sqlConnection;

			command.CommandText =
				"SELECT sifTablica, nazTablica, nazSQLTablica " +
				"FROM tablica " +
				"WHERE sifTipTablica = 1 ";

			DataTable factTablesDataTable = new DataTable();
			factTablesDataTable.Load(command.ExecuteReader());

			foreach (DataRow row in factTablesDataTable.Rows)
			{
				int number = int.Parse(row.ItemArray[0].ToString());
				string name = row.ItemArray[1].ToString().Trim();
				string dbName = row.ItemArray[2].ToString().Trim();

				FactTable factTable = new FactTable(number, name, dbName);

				queryMeasures(factTable);
				getDimensions(factTable);

				factTables.Add(factTable);
			}
			return factTables;
		}

		private static void queryMeasures(FactTable factTable)
		{
			SqlCommand command = new SqlCommand();
			command.Connection = sqlConnection;

			command.CommandText =
				@"
				SELECT rbrAtrib
					  ,imeAtrib
					  ,imeSQLAtrib
				  FROM tabAtribut
				 WHERE sifTipAtrib = 1
				   AND sifTablica = " + factTable.Number;

			DataTable measuresDataTable = new DataTable();
			measuresDataTable.Load(command.ExecuteReader());

			foreach (DataRow row in measuresDataTable.Rows)
			{
				int number = int.Parse(row.ItemArray[0].ToString());
				string name = row.ItemArray[1].ToString().Trim();
				string dbName = row.ItemArray[2].ToString().Trim();

				Measure measure = new Measure(factTable.Number, number, name, dbName);

				queryAggregateFunc(measure);

				factTable.AddMeasure(measure);
			}
		}

		private static void queryAggregateFunc(Measure measure)
		{
			SqlCommand command = new SqlCommand();
			command.Connection = sqlConnection;

			command.CommandText =
				@"
SELECT nazAgrFun
  FROM tabAtribut, tabAtributAgrFun, agrFun
 WHERE tabAtributAgrFun.sifTablica = tabAtribut.sifTablica
   AND tabAtributAgrFun.rbrAtrib = tabAtribut.rbrAtrib
   AND tabAtributAgrFun.sifAgrFun = agrFun.sifAgrFun
   AND tabAtributAgrFun.sifTablica = " + measure.TableNumber + @"
   AND tabAtributAgrFun.rbrAtrib = " + measure.Number;

			DataTable measuresDataTable = new DataTable();
			measuresDataTable.Load(command.ExecuteReader());

			foreach (DataRow row in measuresDataTable.Rows)
			{
				string functionName = row.ItemArray[0].ToString().Trim();
				measure.AddAggregateFunc(functionName);
			}
		}

		private static void getDimensions(FactTable factTable)
		{
			List<Column> keys = fillKeys(factTable);

			foreach (Column key in keys)
			{
				Dimension dim = compileDimension(key);
				
				factTable.AddDimension(key, dim);
			}
		}

		private static List<Column> fillKeys(FactTable factTable)
		{
			List<Column> keys = new List<Column>();

			SqlCommand command = new SqlCommand();
			command.Connection = sqlConnection;

			command.CommandText =
				@"
SELECT rbrAtrib, imeAtrib, imeSQLAtrib
  FROM tabAtribut, dimCinj
 WHERE tabAtribut.sifTablica = dimCinj.sifCinjTablica
   AND tabAtribut.rbrAtrib = dimCinj.rbrCinj
   AND sifTipAtrib = 3
   AND sifTablica = " + factTable.Number;

			DataTable keysTable = new DataTable();
			keysTable.Load(command.ExecuteReader());

			foreach (DataRow row in keysTable.Rows)
			{
				int number = int.Parse(row.ItemArray[0].ToString());
				string name = row.ItemArray[1].ToString().Trim();
				string dbName = row.ItemArray[2].ToString().Trim();

				Column key = new Column(factTable.Number, number, name, dbName);
				keys.Add(key);
			}

			return keys;
		}

		private static Dimension compileDimension(Column fKey)
		{
			Column dkey = queryDimKey(fKey);

			Dimension dim = queryDimension(dkey);
			return dim;
		}

		private static Column queryDimKey(Column fKey)
		{
			SqlCommand command = new SqlCommand();
			command.Connection = sqlConnection;

			command.CommandText =
				@"
SELECT sifDimTablica, rbrDim, imeAtrib, imeSQLAtrib
  FROM dimCinj, tabAtribut
 WHERE dimCinj.sifDimTablica = tabAtribut.sifTablica
   AND dimCinj.rbrDim = tabAtribut.rbrAtrib
   AND dimCinj.sifCinjTablica = " + fKey.TableNumber + @"
   AND dimCinj.rbrCinj = " + fKey.Number;

			DataTable dimKey = new DataTable();
			dimKey.Load(command.ExecuteReader());

			int tableNumber = int.Parse(dimKey.Rows[0].ItemArray[0].ToString());
			int number = int.Parse(dimKey.Rows[0].ItemArray[1].ToString());
			string name = dimKey.Rows[0].ItemArray[2].ToString().Trim();
			string dbName = dimKey.Rows[0].ItemArray[3].ToString().Trim();

			return new Column(tableNumber, number, name, dbName);
		}

		private static Dimension queryDimension(Column dkey)
		{
			SqlCommand command = new SqlCommand();
			command.Connection = sqlConnection;

			command.CommandText =
				@"
SELECT tablica.nazTablica, tablica.nazSQLTablica
  FROM tablica
 WHERE tablica.sifTablica = " + dkey.TableNumber;

			DataTable dimensions = new DataTable();
			dimensions.Load(command.ExecuteReader());

			string name = dimensions.Rows[0].ItemArray[0].ToString().Trim();
			string dbName = dimensions.Rows[0].ItemArray[1].ToString().Trim();

			Dimension dim = new Dimension(dkey.TableNumber, name, dbName, dkey);

			queryAttributes(dim);

			return dim;
		}

		private static void queryAttributes(Dimension dim)
		{
			SqlCommand command = new SqlCommand();
			command.Connection = sqlConnection;

			command.CommandText =
				@"
SELECT rbrAtrib, imeAtrib, imeSQLAtrib
  FROM tabAtribut
 WHERE sifTablica = " + dim.Number;

			DataTable attributes = new DataTable();
			attributes.Load(command.ExecuteReader());

			foreach (DataRow row in attributes.Rows)
			{
				int number = int.Parse(row.ItemArray[0].ToString());
				string name = row.ItemArray[1].ToString().Trim();
				string dbName = row.ItemArray[2].ToString().Trim();

				Column key = new Column(dim.Number, number, name, dbName);
				dim.AddAttribute(key);
			}
		}

		public static DataTable ExecuteSQL(string commandText)
		{
			SqlCommand command = new SqlCommand();
			command.Connection = sqlConnection;

			command.CommandText = commandText;

			DataTable result = new DataTable();
			result.Load(command.ExecuteReader());

			return result;
		}
	}
}
