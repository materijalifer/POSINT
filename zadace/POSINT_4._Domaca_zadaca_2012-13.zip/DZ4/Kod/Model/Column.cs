﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
	public class Column
	{
		private int tableNumber;
		public int TableNumber
		{
			get { return tableNumber; }
		}

		private int number;
		public int Number
		{
			get { return number; }
		}


		private string name;
		public string Name
		{
			get { return name; }
		}

		private string dbName;
		public string DBName
		{
			get { return dbName; }
		}

		private bool selected;
		public bool Selected
		{
			get { return selected; }
			set { selected = value; }
		}

		public Column(int tableNumber, int number, string name, string dbName)
		{
			this.tableNumber = tableNumber;
			this.number = number;
			this.name = name;
			this.dbName = dbName;
		}
	}
}
