﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
	public static class ConnectionRepository
	{
		private static List<IObserver> observers = new List<IObserver>();

		public static void AddObserver(IObserver observer)
		{
			if (!observers.Contains(observer))
			{
				observers.Add(observer);
			}
		}

		public static void RemoveObserver(IObserver observer)
		{
			observers.Remove(observer);
		}


		private static List<string> connections = new List<string>();
		public static IList<string> Connections
		{
			get { return connections.AsReadOnly(); }
		}

		public static void AddConnection(string connection)
		{
			if (!connections.Contains(connection))
			{
				connections.Add(connection);
			}

			notifyObservers();
		}

		public static void AddConnectionFirst(string connection)
		{
			List<string> newConn = new List<string>();
			newConn.Add(connection);
			if (connections.Contains(connection))
			{
				connections.Remove(connection);
			}

			newConn.AddRange(connections);
			connections = newConn;

			notifyObservers();
		}

		public static void RemoveConnection(string connection)
		{
			connections.Remove(connection);
		}


		private static void notifyObservers()
		{
			foreach (IObserver observer in observers)
			{
				observer.Update();
			}
		}
	}
}
