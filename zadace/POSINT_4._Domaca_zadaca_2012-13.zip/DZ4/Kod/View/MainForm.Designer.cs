﻿namespace View
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.factPanel = new System.Windows.Forms.Panel();
			this.measuresPanel = new System.Windows.Forms.Panel();
			this.dimensionsPanel = new System.Windows.Forms.Panel();
			this.textBoxSQL = new System.Windows.Forms.TextBox();
			this.dataGridView = new System.Windows.Forms.DataGridView();
			this.buttonSend = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
			this.SuspendLayout();
			// 
			// factPanel
			// 
			this.factPanel.AutoScroll = true;
			this.factPanel.Location = new System.Drawing.Point(20, 18);
			this.factPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.factPanel.Name = "factPanel";
			this.factPanel.Size = new System.Drawing.Size(267, 185);
			this.factPanel.TabIndex = 0;
			// 
			// measuresPanel
			// 
			this.measuresPanel.AutoScroll = true;
			this.measuresPanel.Location = new System.Drawing.Point(20, 208);
			this.measuresPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.measuresPanel.Name = "measuresPanel";
			this.measuresPanel.Size = new System.Drawing.Size(267, 185);
			this.measuresPanel.TabIndex = 1;
			// 
			// dimensionsPanel
			// 
			this.dimensionsPanel.Location = new System.Drawing.Point(20, 399);
			this.dimensionsPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.dimensionsPanel.Name = "dimensionsPanel";
			this.dimensionsPanel.Size = new System.Drawing.Size(267, 185);
			this.dimensionsPanel.TabIndex = 2;
			// 
			// textBoxSQL
			// 
			this.textBoxSQL.AcceptsReturn = true;
			this.textBoxSQL.AcceptsTab = true;
			this.textBoxSQL.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxSQL.Location = new System.Drawing.Point(293, 18);
			this.textBoxSQL.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.textBoxSQL.Multiline = true;
			this.textBoxSQL.Name = "textBoxSQL";
			this.textBoxSQL.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.textBoxSQL.Size = new System.Drawing.Size(592, 184);
			this.textBoxSQL.TabIndex = 3;
			// 
			// dataGridView
			// 
			this.dataGridView.AllowUserToAddRows = false;
			this.dataGridView.AllowUserToDeleteRows = false;
			this.dataGridView.AllowUserToOrderColumns = true;
			this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			this.dataGridView.Location = new System.Drawing.Point(295, 261);
			this.dataGridView.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.dataGridView.Name = "dataGridView";
			this.dataGridView.Size = new System.Drawing.Size(592, 322);
			this.dataGridView.TabIndex = 4;
			// 
			// buttonSend
			// 
			this.buttonSend.Enabled = false;
			this.buttonSend.Location = new System.Drawing.Point(295, 210);
			this.buttonSend.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.buttonSend.Name = "buttonSend";
			this.buttonSend.Size = new System.Drawing.Size(592, 43);
			this.buttonSend.TabIndex = 5;
			this.buttonSend.Text = "Pošalji upit prema bazi";
			this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(903, 649);
			this.Controls.Add(this.buttonSend);
			this.Controls.Add(this.dataGridView);
			this.Controls.Add(this.textBoxSQL);
			this.Controls.Add(this.dimensionsPanel);
			this.Controls.Add(this.measuresPanel);
			this.Controls.Add(this.factPanel);
			this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.Name = "MainForm";
			this.Text = "DZ4";
			((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Panel factPanel;
		private System.Windows.Forms.Panel measuresPanel;
		private System.Windows.Forms.Panel dimensionsPanel;
		private System.Windows.Forms.TextBox textBoxSQL;
		private System.Windows.Forms.DataGridView dataGridView;
		private System.Windows.Forms.Button buttonSend;
	}
}

