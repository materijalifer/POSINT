﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

namespace View
{
	public class GraphicDrawerForms
	{
		private Form form;

		private int currentTop = 15;
		private int currentLeft = 15;

		private int horizontalSpaceBetween = 5;
		private int verticalSpaceBetween = 15;

		private int nextTop = 15;
		private int minimumWidth = 15;

		private int initialTextBoxWidth = 200;
		
		public void GoToNewLine()
		{
			this.currentTop = this.nextTop;
			
			this.currentLeft = 15;
		}

		public GraphicDrawerForms(Form form)
		{
			this.form = form;
			this.ForceMinimumSize = true;
			form.Size = new Size(1, 1);
		}

		public TextBox AddTextBox()
		{
			TextBox textBox = new TextBox();
			textBox.Width = initialTextBoxWidth;
			textBox.Left = currentLeft;
			textBox.Top = currentTop;

			UpdateForm(textBox);

			return textBox;
		}

		public TextBox AddTextBox(string name, char passwordChar)
		{
			TextBox textBox = new TextBox();

			textBox.Width = initialTextBoxWidth;
			textBox.Left = currentLeft;
			textBox.Top = currentTop;
			textBox.PasswordChar = passwordChar;

			UpdateForm(textBox);

			return textBox;
		}

		public Label AddLabel(string text)
		{
			Label label = new Label();
			label.AutoSize = true;
			label.Text = text;
			label.Left = currentLeft;
			label.Top = currentTop + 3;

			UpdateForm(label);
			return label;
		}

		public Label AddLabelButton(string text, EventHandler button_Click)
		{
			Label label = new Label();
			label.AutoSize = true;
			label.Font = new Font(label.Font, FontStyle.Underline);
			label.Text = text;
			label.Left = currentLeft;
			label.Top = currentTop;
			label.Click += new EventHandler(button_Click);

			UpdateForm(label);

			return label;
		}

		public Button AddButton(string text, EventHandler button_Click)
		{
			Button button = new Button();
			button.AutoSize = true;
			button.Text = text;
			button.Left = currentLeft;
			button.Top = currentTop;
			button.Click += new EventHandler(button_Click);

			UpdateForm(button);

			return button;
		}

		public CheckedListBox AddCheckedListBox(List<string> options)
		{
			CheckedListBox checkedListBox = new CheckedListBox();
			checkedListBox.AutoSize = true;

			foreach (string text in options)
			{
				checkedListBox.Items.Add(options);
			}

			checkedListBox.Left = currentLeft;
			checkedListBox.Top = currentTop + 3;

			UpdateForm(checkedListBox);
			return checkedListBox;
		}

		public RadioButton AddRadioButton(string option)
		{
			RadioButton radioButton = new RadioButton();
			radioButton.AutoSize = true;

			radioButton.Text = option;

			radioButton.Left = currentLeft;
			radioButton.Top = currentTop + 3;

			UpdateForm(radioButton);
			return radioButton;
		}
		
		public void UpdateForm(Control control)
		{
			this.form.Controls.Add(control);

			this.currentLeft = this.currentLeft + control.Width + horizontalSpaceBetween;

			if (this.nextTop < this.currentTop + control.Height + verticalSpaceBetween)
			{
				this.nextTop = this.currentTop + control.Height + verticalSpaceBetween;
			}

			this.minimumWidth = this.currentLeft + 10;
			form.MinimumSize = new Size(this.minimumWidth, this.nextTop + 30);
		}

		public bool ForceMinimumSize
		{
			set
			{
				if (value)
				{
					this.form.AutoSize = true;
					this.form.AutoScroll = false;
					this.form.AutoSizeMode = AutoSizeMode.GrowOnly;
					this.form.MinimumSize = new Size(this.minimumWidth, this.nextTop + 30);
				}
				else
				{
					this.form.AutoSize = false;
					this.form.AutoScroll = true;
					this.form.MinimumSize = new Size(0, 0);
				}
			}
		}

	}
}
