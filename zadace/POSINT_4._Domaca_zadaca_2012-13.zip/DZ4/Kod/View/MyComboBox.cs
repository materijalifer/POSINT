﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Model;

namespace View
{
	class MyComboBox : ComboBox
	{
		public Measure Value { get; set; }
	}
}
