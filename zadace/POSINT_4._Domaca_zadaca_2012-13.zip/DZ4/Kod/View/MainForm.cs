﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Controller;
using Model;

namespace View
{
	public partial class MainForm : Form, IMainForm
	{
		Label factLabel = new Label();
		Label measureLabel = new Label();
		Label dimensionLabel = new Label();

		int leftBorder = 0;

		TreeView treeView = new TreeView();

		public MainForm()
		{
			InitializeComponent();

			this.treeView.AfterCheck += new TreeViewEventHandler(treeView_AfterCheck);
			this.treeView.CheckBoxes = true;
			this.dimensionsPanel.Controls.Add(treeView);
			treeView.Dock = DockStyle.Fill;

			this.buttonSend.Enabled = false;

			this.factLabel.Text = "Tablice činjenica:";
			this.measureLabel.Text = "Mjere:";
			this.dimensionLabel.Text = "Dimenzije:";

			this.textBoxSQL.Left = leftBorder + 10;
			this.textBoxSQL.Width = this.Width - this.textBoxSQL.Left - 30;

			this.dataGridView.Left = leftBorder + 10;
			this.dataGridView.Width = this.Width - this.dataGridView.Left - 30;
			this.dataGridView.Height = this.Height - this.dataGridView.Top - 50;

			this.textBoxSQL.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
			this.buttonSend.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
			this.dataGridView.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;

			this.factLabel.AutoSize = true;
			this.measureLabel.AutoSize = true;
			this.dimensionLabel.AutoSize = true;

			this.measureLabel.Visible = false;
			this.dimensionLabel.Visible = false;

			this.factLabel.Left = measureLabel.Left = dimensionLabel.Left = 15;
			this.factLabel.Top = 15;

			this.Controls.Add(factLabel);
			this.Controls.Add(measureLabel);
			this.Controls.Add(dimensionLabel);

			this.AutoScroll = true;

			this.factPanel.AutoScroll = false;
			this.factPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.factPanel.AutoSize = true;

			this.measuresPanel.AutoScroll = false;
			this.measuresPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.measuresPanel.AutoSize = true;

			this.textBoxSQL.Font = new Font("Consolas", 10);

			this.InitializeData();
		}
		
		private void InitializeData()
		{
			int startLeft = 15;
			int endLeft = 0;
			int top = 15;

			MyRadioButton last = null;
			foreach (FactTable factTable in FactTableRepository.FactTables)
			{
				MyRadioButton rButton = new MyRadioButton();
				rButton.AutoSize = true;
				rButton.Text = factTable.Name;
				rButton.Left = startLeft;
				rButton.Top = top;
				rButton.Value = factTable;
				rButton.Click += new EventHandler(rButton_Click);
				last = rButton;
				top = top + rButton.Height + 10;

				this.factPanel.Controls.Add(rButton);

				if (endLeft < rButton.Width)
				{
					endLeft = rButton.Width;
				}
			}

			if (last != null)
			{
				last.Checked = true;
			}

			this.factPanel.Top = this.factLabel.Bottom + 10;
		}

		private void UpdateMeasurePanel(FactTable factTable)
		{
			this.measureLabel.Visible = true;
			this.measureLabel.Top = this.factPanel.Top + this.factPanel.Height + 15;

			this.measuresPanel.Left = 15;
			this.measuresPanel.Top = this.measureLabel.Top + this.measureLabel.Height + 15;
			this.measuresPanel.Controls.Clear();

			if (factTable.Measures.Count == 0)
			{
				this.measureLabel.Text = "Nema mjera u tablici činjenica";
			}
			else
			{
				this.measureLabel.Text = "Mjere:";
				int startLeft = 15;
				int endLeft = 0;
				int top = 15;

				foreach (Measure measure in factTable.Measures)
				{
					MyCheckBox checkBox = new MyCheckBox();
					checkBox.Checked = measure.Selected;
					checkBox.Text = measure.Name;
					checkBox.AutoSize = true;
					checkBox.Left = startLeft;
					checkBox.Top = top + 7;
					checkBox.Value = measure;
					checkBox.Click += new EventHandler(checkBox_Click);
					this.measuresPanel.Controls.Add(checkBox);

					int width = 0;
					MyComboBox comboBox = new MyComboBox();
					comboBox.DropDownStyle = ComboBoxStyle.DropDownList;

					foreach (string function in measure.AggregateFunc)
					{
						comboBox.Items.Add(function);

						Label label = new Label();
						label.Text = function.Trim();
						label.AutoSize = true;
						this.Controls.Add(label);
						if (width < label.Width)
						{
							width = label.Width;
						}
						this.Controls.Remove(label);
					}
					comboBox.Width = width + 20;
					comboBox.Value = measure;
					comboBox.Left = checkBox.Left + checkBox.Width + 10;
					comboBox.Top = top + 3;

					comboBox.SelectedIndexChanged += new EventHandler(comboBox_SelectedIndexChanged);
					if (comboBox.Items.Count == 0)
					{
						comboBox.Enabled = false;
					}
					else
					{
						if (string.IsNullOrEmpty(measure.SelectedFunction))
						{
							comboBox.SelectedItem = comboBox.Items[0];
						}
						else
						{
							comboBox.SelectedItem = measure.SelectedFunction;
						}
					}

					this.measuresPanel.Controls.Add(comboBox);

					top = top + checkBox.Height + 10;

					if (endLeft < comboBox.Left + comboBox.Width)
					{
						endLeft = comboBox.Left + comboBox.Width;
					}
				}
			}

			if (leftBorder < this.measuresPanel.Left + this.measuresPanel.Width + 15)
			{
				leftBorder = this.measuresPanel.Left + this.measuresPanel.Width + 15;
			}
		}

		private void UpdateDimensionPanel(FactTable factTable)
		{
			this.dimensionLabel.Visible = true;
			this.dimensionLabel.Top = this.measuresPanel.Top + this.measuresPanel.Height + 15;

			this.dimensionsPanel.Left = 15;
			this.dimensionsPanel.Top = this.dimensionLabel.Top + this.dimensionLabel.Height + 15;

			this.treeView.Nodes.Clear();

			if (factTable.Dimensions.Count == 0)
			{
				this.dimensionLabel.Text = "Nema dimenzija za ovu tablicu činjenica.";
	
				this.dimensionsPanel.Visible = false;
			}
			else
			{
				this.dimensionLabel.Text = "Dimenzije:";
				this.dimensionsPanel.Visible = true;
				foreach (Dimension dimension in factTable.Dimensions.Values)
				{
					TreeNode nodeDim = new TreeNode();
					nodeDim.Text = dimension.Name;
					treeView.Nodes.Add(nodeDim);

					foreach (Column attribute in dimension.Attributes)
					{
						MyTreeNode nodeAtt = new MyTreeNode();
						nodeAtt.Value = attribute;
						nodeAtt.Text = attribute.Name;
						nodeDim.Nodes.Add(nodeAtt);
					}
				}
			}

			this.defineBorder();
			this.dimensionsPanel.Width = this.leftBorder - this.dimensionsPanel.Left;

			this.dimensionsPanel.Height = this.Height - this.dimensionsPanel.Top - 50;
			this.dimensionsPanel.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Bottom;
		}


		void treeView_AfterCheck(object sender, TreeViewEventArgs e)
		{
			TreeNode node = e.Node as TreeNode;

			if (node != null)
			{
				MyTreeNode myNode = node as MyTreeNode;

				if (myNode != null)
				{
					myNode.Value.Selected = myNode.Checked;
					
					if (node.Checked && node.Parent != null && !node.Parent.Checked)
					{
						node.Parent.Checked = true;
					}

					if (!myNode.Checked)
					{
						bool someSiblingsChecked = false;
						foreach (TreeNode siblingNode in myNode.Parent.Nodes)
						{
							someSiblingsChecked = someSiblingsChecked || siblingNode.Checked;
						}

						if (!someSiblingsChecked)
						{
							myNode.Parent.Checked = false;
						}
					}
				}
				else
				{
					bool someNodesChecked = false;
					foreach (TreeNode childNode in node.Nodes)
					{
						someNodesChecked = someNodesChecked || childNode.Checked;
					}

					if (!someNodesChecked && node.Checked || someNodesChecked && !node.Checked)
					{
						foreach (TreeNode childNode in node.Nodes)
						{
							childNode.Checked = node.Checked;
						}
					}					
				}
			}

			this.UpdateSQL();
		}

		void comboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			MyComboBox cSender = sender as MyComboBox;

			if (cSender != null)
			{
				cSender.Value.SelectedFunction = cSender.Text;
			}

			this.UpdateSQL();
		}

		void rButton_Click(object sender, EventArgs e)
		{
			MyRadioButton rSender = sender as MyRadioButton;

			if (rSender != null)
			{
				FactTable factTable = rSender.Value;
				this.UpdateMeasurePanel(factTable);

				defineBorder();

				this.UpdateDimensionPanel(factTable);

				this.textBoxSQL.Left = leftBorder + 10;
				this.textBoxSQL.Width = this.Width - this.textBoxSQL.Left - 30;

				this.buttonSend.Left = leftBorder + 10;
				this.buttonSend.Width = this.Width - this.textBoxSQL.Left - 30;

				this.dataGridView.Left = leftBorder + 10;
				this.dataGridView.Width = this.Width - this.dataGridView.Left - 30;
				this.dataGridView.Height = this.Height - this.dataGridView.Top - 50;

				FactTableRepository.SelectedFactTable = factTable;
			}

			this.UpdateSQL();
		}

		void checkBox_Click(object sender, EventArgs e)
		{
			MyCheckBox cSender = sender as MyCheckBox;

			if (cSender != null)
			{
				Column measure = cSender.Value;
				measure.Selected = cSender.Checked;
			}

			this.UpdateSQL();
		}


		private void defineBorder()
		{
			leftBorder = 0;
			moveLeftBorderIfNeeded(factPanel);
			moveLeftBorderIfNeeded(measuresPanel);

			moveLeftBorderIfNeeded(factLabel);
			moveLeftBorderIfNeeded(measureLabel);
			moveLeftBorderIfNeeded(dimensionLabel);
		}

		private void moveLeftBorderIfNeeded(Control control)
		{
			if (this.leftBorder < control.Left + control.Width)
			{
				this.leftBorder = control.Left + control.Width;
			}
		}


		private void UpdateSQL()
		{
			FactTable factTable = FactTableRepository.SelectedFactTable;
			string select = "  SELECT ";
			int measureCounter = 0;
			string selectSpace = Environment.NewLine + "        ,";
			foreach (Measure measure in factTable.Measures)
			{
				if (measure.Selected)
				{
					this.buttonSend.Enabled = true;
					if(measureCounter != 0)
					{
						select += selectSpace;
					}
					select += measure.SelectedFunction + "(" + factTable.DBName + "." + measure.DBName;
					select += ") AS '" + measure.SelectedFunction + " " + measure.Name + "'";
					measureCounter++;
				}
			}
			if (measureCounter != 0)
			{
				string from = "    FROM " + factTable.DBName;
				string where = "  WHERE ";
				string groupBy = "GROUP BY ";

				int dimensionCounter = 0;
				foreach (var item in FactTableRepository.SelectedFactTable.Dimensions)
				{
					int attributeCounter = 0;
					foreach (Column attribute in item.Value.Attributes)
					{
						if (attribute.Selected)
						{
							string attributeText = item.Value.DBName + "." + attribute.DBName;

							select += selectSpace;
							select += attributeText + " AS '" + attribute.Name + "'";

							if (attributeCounter != 0 || dimensionCounter != 0)
							{
								groupBy += selectSpace;
							}

							groupBy += attributeText;
							attributeCounter++;
						}
					}

					if (attributeCounter > 0)
					{
						from += ", " + item.Value.DBName;

						if (dimensionCounter != 0)
						{
							where += Environment.NewLine + "     AND ";
						}

						where += factTable.DBName + "." + item.Key.DBName + " = "
							+ item.Value.DBName + "." + item.Value.Key.DBName;

						dimensionCounter++;
					}
				}

				select += Environment.NewLine + from;
				if (dimensionCounter != 0)
				{
					select += Environment.NewLine + " " + where;
					select += Environment.NewLine + groupBy;
				}

				this.textBoxSQL.Text = select;
			}
			else
			{
				this.textBoxSQL.Text = "Odaberite barem jednu mjeru";
				this.buttonSend.Enabled = false;
			}
		}

		private void buttonSend_Click(object sender, EventArgs e)
		{
			try
			{
				this.dataGridView.DataSource = ConnectionKeeper.ExecuteSQL(this.textBoxSQL.Text);
			}
			catch(Exception ex)
			{
				IMessageForm mf = new MessageForm();
				mf.ShowErrorMessage(ex.Message, "Upit nije proveden");
			}
		}
	}
}
