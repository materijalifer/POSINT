﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

using Controller;

namespace View
{
	public class MessageForm : Form, IMessageForm
	{
		private List<string> options = new List<string>();

		private string defaultOption = null;

		GraphicDrawerForms drawer;

		string returnValue = "";

		public MessageForm()
		{
			this.drawer = new GraphicDrawerForms(this);
		}

		public void AddAction(string action)
		{
			if (this.defaultOption == null)
			{
				defaultOption = action;
			}

			this.options.Add(action);
		}

		public string DefaultAction
		{
			set
			{
				bool found = false;
				foreach (string option in this.options)
				{
					if (string.Equals(option, value))
					{
						found = true;
						this.defaultOption = value;
					}
				}

				if (!found)
				{
					throw new ArgumentOutOfRangeException("defaultOption", "Nije nađena akcija među svim akcijma.");
				}
			}
		}

		public string ShowToUser(string message, string label)
		{
			this.Text = label;

			this.drawer.AddLabel(message);
			this.drawer.GoToNewLine();

			foreach (string option in this.options)
			{
				Button button = this.drawer.AddButton(option, returnString);
				if (string.Equals(option, defaultOption))
				{
					button.Select();
				}
			}

			this.ShowDialog();

			return returnValue;
		}

		public void ShowErrorMessage(string message, string label)
		{
			MessageBox.Show(message, label, MessageBoxButtons.OK, MessageBoxIcon.Error);
		}

		private void returnString(object o, EventArgs e)
		{
			Button button = o as Button;
			returnValue = button.Text;
			this.Close();
		}
	}
}
