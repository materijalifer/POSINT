﻿using System;
using System.Collections.Generic;
using System.Text;

using Model;
using System.Windows.Forms;

namespace View
{
	class MyTreeNode : TreeNode
	{
		public Column Value { get; set; }
	}
}
