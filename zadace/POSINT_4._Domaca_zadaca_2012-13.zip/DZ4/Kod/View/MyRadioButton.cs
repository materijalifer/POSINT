﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Model;

namespace View
{
	public class MyRadioButton : RadioButton
	{
		public FactTable Value { get; set; }
	}
}
