﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Model;

namespace View
{
	class MyCheckBox : CheckBox
	{
		public Column Value { get; set; }
	}
}
