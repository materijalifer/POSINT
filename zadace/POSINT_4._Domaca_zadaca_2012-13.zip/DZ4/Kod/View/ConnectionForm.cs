﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Model;
using Controller;

namespace View
{
	public partial class ConnectionForm : Form , IConnectionForm
	{
		ConnectionFormController controller;

		public ConnectionForm()
		{
			this.controller = new ConnectionFormController(this);
			InitializeComponent();

			this.initializeData();
		}

		private void initializeData()
		{
			int width = 0;
			foreach (string connection in ConnectionRepository.Connections)
			{
				Label label = new Label();
				this.Controls.Add(label);
				label.AutoSize = true;
				label.Text = connection;
				if (width < label.Width)
				{
					width = label.Width;
				}
				this.Controls.Remove(label);

				this.comboBox.Items.Add(connection);
			}

			if (comboBox.Items.Count > 0)
			{
				comboBox.SelectedIndex = 0;
			}

			this.Width = width + 50;
		}

		private void buttonConnect_Click(object sender, EventArgs e)
		{
			string conn = this.comboBox.Text;
			this.controller.Connect(conn, new MessageForm());
		}
	}
}
