﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

using Controller;
using Model;

namespace View
{
	static class Program
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			MainController.InitializeConnections();

			ConnectionForm connectionForm = new ConnectionForm();
			connectionForm.ShowDialog();

			if (!ConnectionKeeper.ConnectionOpen)
			{

			}
			else
			{
				MainController.InitializeData();
				try
				{
					Application.Run(new MainForm());
				}
				catch (Exception ex)
				{
					IMessageForm mf = new MessageForm();
					mf.ShowErrorMessage(ex.Message, "Aplikacija izlazi sa greškom");
				}
			}

			MainController.CleanUp();
		}
	}
}
